package com.example.CRUDApplicator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudApplicatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
